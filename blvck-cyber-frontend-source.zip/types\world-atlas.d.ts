declare module "world-atlas/countries-110m.json" {
  const value: any
  export default value
}